library(testthat)

library(weatherapi)
test_check("weatherapi")

