# 534-project
group project for Data 534.
[![xintian927](https://circleci.com/gh/xintian927/534-project.svg?style=svg)](https://app.circleci.com/pipelines/github/xintian927/534-project?filter=all)
